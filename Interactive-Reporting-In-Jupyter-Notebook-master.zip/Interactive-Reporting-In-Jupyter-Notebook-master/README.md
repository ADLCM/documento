# Interactive Reporting In Jupyter Notebook
This sample shows how to create a Jupyter Notebook with the interactive pivot table and pivot charts components. This approach can be used for data analysis and data visualization purposes. 

The data used in this sample can be downloaded from [Kaggle](https://www.kaggle.com/neuromusic/avocado-prices/home). 

## References

* [Embedding Flexmonster Pivot Table into web applications](https://www.flexmonster.com/api/?r=gt_jupyter)
